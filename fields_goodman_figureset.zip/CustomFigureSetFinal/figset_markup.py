from pathlib import Path
figurenumber = 17
cwd = Path.cwd()
pdfs = cwd.glob("*.pdf")
print("\\figsetstart")
print(f"\\figsetnum{{{figurenumber}}}")
print('\\figsettitle{{All Tier 4 Candidates}}')
groupnum = 1
for file in pdfs:
    (star,datestr) = file.stem.split("_",maxsplit=1)
    (datestr,discard) = datestr.split(".",maxsplit=1)
    datestr = datestr.replace("T"," ")
    datestr = datestr.replace("_",":")
    print("\\figsetgrpstart")
    print(f"\\figsetgrpnum{{{figurenumber}.{groupnum}}}")
    print(f'\\figsetgrptitle{{{file.stem}}}')
    print(f"\\figsetplot{{{file.stem+file.suffix}}}")
    print(f"\\figsetgrpnote{{Star: {star}, Observation Date/Time: {datestr}. Top panel: reduced spectrum. Bottom panel: subsection of the corresponding CCD image for this wavelength range.}}")
    print("\\figsetgrpend")
    groupnum += 1
print("\\figsetend")